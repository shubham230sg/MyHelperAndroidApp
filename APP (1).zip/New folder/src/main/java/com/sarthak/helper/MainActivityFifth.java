package com.sarthak.helper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class MainActivityFifth extends AppCompatActivity {

    Contact contact;

    EditText nameText , numberText , idText;
    TextView textView;
    Button btn_add , btn_view , btn_update , btn_delete ;
    AdView mAdView;

    public void goToHome(View view) {
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }

    public void goToSecond(View view) {
        Intent intent = new Intent(getApplicationContext(),MainActivitySecond.class);
        startActivity(intent);
    }

    public void goToThird(View view) {
        Intent intent = new Intent(getApplicationContext(),MainActivityThird.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_fifth);

        contact = new Contact(this);

        nameText = findViewById(R.id.nameText);
        numberText = findViewById(R.id.numberText);
        idText = findViewById(R.id.idText);
        btn_add = findViewById(R.id.btn_add);
        btn_view = findViewById(R.id.btn_view);
        btn_update = findViewById(R.id.btn_update);
        btn_delete = findViewById(R.id.btn_delete);
        textView = findViewById(R.id.textView);

        AddData();
        ViewData();
        updateData();
        deleteData();

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    public void AddData() {
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameText.getText().toString();
                String number = numberText.getText().toString();

                boolean insertData = contact.addData(name, number);

                if (insertData == true) {
                    Toast.makeText(MainActivityFifth.this, "Data Entered !", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivityFifth.this, "Some Problem !", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public  void ViewData() {
        btn_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor data = contact.showData();

                if (data.getCount() == 0) {
                    display("ERROR", "NO DATA FOUND");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (data.moveToNext()) {
                    buffer.append("ID : " + data.getString(0) + "\n");
                    buffer.append("NAME : " + data.getString(1) +  "\n");
                    buffer.append("Number : " +data.getString(2) + "\n \n");
                }
                display("ALL STORED DATA : ", buffer.toString());


            }
        });
    }

    public void display(String title, String message) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void updateData() {
        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = idText.getText().toString().length();
                if(temp>0) {
                    boolean update = contact.updateData(idText.getText().toString(),nameText.getText().toString(), numberText.getText().toString());
                    if(update == true) {
                        Toast.makeText(MainActivityFifth.this, "UPDATED !" , Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(MainActivityFifth.this, "Some Problem !", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(MainActivityFifth.this, "Some Problem !", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void deleteData() {
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = idText.getText().toString().length();
                if(temp>0) {
                    Integer deleteRow = contact.deleteData(idText.getText().toString());
                    if(deleteRow > 0) {
                        Toast.makeText(MainActivityFifth.this, "DELETED !" , Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(MainActivityFifth.this, "SOME PROBLEM !" , Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(MainActivityFifth.this, "NO SUCH ID IS THERE !" , Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}