package com.sarthak.helper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import java.util.ArrayList;
import java.util.List;

public class MainActivitySecond extends AppCompatActivity {

    private static final int CONTACT_PICKER_REQUEST = 3;
    Button num1, num2, num3, num4, num5, num6, num7, num8, num9, num10 ;
    EditText Number1, Number2;
    List< ContactResult > results = new ArrayList <>();
    AdView mAdView;

    public void goToHome(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }

    public void goToThird(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivityThird.class);
        startActivity(intent);
    }

    public void goToFourth(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivityFifth.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_second);

        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        num3 = findViewById(R.id.num3);
        num4 = findViewById(R.id.num4);
        num5 = findViewById(R.id.num5);
        num6 = findViewById(R.id.num6);
        num7 = findViewById(R.id.num7);
        num8 = findViewById(R.id.num8);
        num9 = findViewById(R.id.num9);
        num10 = findViewById(R.id.num10);

        Number1 = findViewById(R.id.Number1);
        Number2 = findViewById(R.id.Number2);

        num1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call1();
            }
        });
        num2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call2();
            }
        });
        num3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call3();
            }
        });
        num4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call4();
            }
        });
        num5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call5();
            }
        });
        num6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call6();
            }
        });
        num7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call7();
            }
        });
        num8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call8();
            }
        });
        num9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call9();
            }
        });
        num10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call10();
            }
        });

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }


    public void call1() {

            String phoneNum = Number1.getText().toString() ;
        if (!phoneNum.isEmpty()) {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phoneNum));
                if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                        Manifest.permission.CALL_PHONE
                ) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                startActivity(callIntent);
        } if (!Number2.getText().toString().isEmpty()) {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            for(int j=0; j<results.size(); j++) {
                callIntent.setData(Uri.parse("tel:" + results.get(j).getPhoneNumbers().get(0).getNumber()));
            }
            if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                    Manifest.permission.CALL_PHONE
            ) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            startActivity(callIntent);
        }
        else {
            Toast.makeText(this, "Please Enter Number !", Toast.LENGTH_SHORT).show();
        }
    }

    public void call2() {

        String phoneNum = Number1.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel: 100"));
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void call3() {

        String phoneNum = Number1.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel: 108"));
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void call4() {

        String phoneNum = Number1.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:181"));
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void call5() {

        String phoneNum = Number1.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel: 1091"));
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void call6() {

        String phoneNum = Number1.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel: 1098"));
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void call7() {

        String phoneNum = Number1.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel: 101"));
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void call8() {

        String phoneNum = Number1.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:1512"));
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void call9() {

        String phoneNum = Number1.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel: 112"));
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void call10() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) ;
        if(permissionCheck == PackageManager.PERMISSION_GRANTED ) {
            choose();
        } else  {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_CONTACTS},7);
        }

    }

    public void choose() {
        new MultiContactPicker.Builder(MainActivitySecond.this) //Activity/fragment context
                                                          .hideScrollbar(false) //Optional - default: false
                                                          .showTrack(true) //Optional - default: true
                                                          .searchIconColor(Color.WHITE) //Option - default: White
                                                          .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                                                          .handleColor(ContextCompat.getColor(MainActivitySecond.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                                          .bubbleColor(ContextCompat.getColor(MainActivitySecond.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                                          .bubbleTextColor(Color.WHITE) //Optional - default: White
                                                          .setTitleText("Select Contacts") //Optional - default: Select Contacts
                                                          .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                                                          .limitToColumn(LimitColumn.NONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                                                          .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                                                                  android.R.anim.fade_in,
                                                                  android.R.anim.fade_out) //Optional - default: No animation overrides
                                                          .showPickerForResult(CONTACT_PICKER_REQUEST);
    }

    public void call11() {

        String phoneNum = Number2.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        for(int j=0; j<results.size(); j++) {
            callIntent.setData(Uri.parse("tel:" + results.get(j).getPhoneNumbers().get(0).getNumber()));
        }
        if (ActivityCompat.checkSelfPermission(MainActivitySecond.this,
                Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CONTACT_PICKER_REQUEST){
            if(resultCode == RESULT_OK) {
                results = MultiContactPicker.obtainResult(data);
                StringBuilder names = new StringBuilder(results.get(0).getDisplayName());
                Number2.setText(names);
            }
        } else if(resultCode == RESULT_CANCELED){
            System.out.println("User closed the picker without selecting items.");
        }
    }
}