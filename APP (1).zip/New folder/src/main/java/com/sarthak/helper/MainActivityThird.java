package com.sarthak.helper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import java.util.ArrayList;
import java.util.List;

public class MainActivityThird extends AppCompatActivity {

    Button btn_bus;
    Button btn_truck;
    Button btn_car;
    Button btn_train;
    Button btn_bike;
    Button btn_activa;
    Button btn_auto;
    Button btn_taxi;
    Button btn_metro;
    Button btn_contact;
    Button send;
    Button btn_whatsApp;
    Button sendToNo;
    TextView textView;
    TextView noTextView;
    TextView numberText;
    EditText vehicleNo;
    EditText info;
    EditText editText;
    TextView numText;
    Button viewImp;
    Contact contact;
    AdView mAdView;

    LocationManager locManager;
    LocationListener li;

    private static final int CONTACT_PICKER_REQUEST = 3;
    List < ContactResult > results = new ArrayList <>();
    Editable temp;

    public void goToSecond(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivitySecond.class);
        startActivity(intent);
    }

    public void goToHome(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }

    public void goToFourth(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivityFifth.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_third);

        btn_bus = findViewById(R.id.btn_bus);
        btn_truck = findViewById(R.id.btn_truck);
        btn_car = findViewById(R.id.btn_car);
        btn_train = findViewById(R.id.btn_train);
        btn_bike = findViewById(R.id.btn_bike);
        btn_activa = findViewById(R.id.btn_activa);
        btn_auto = findViewById(R.id.btn_auto);
        btn_taxi = findViewById(R.id.btn_taxi);
        btn_metro = findViewById(R.id.btn_metro);
        btn_contact = findViewById(R.id.btn_contact);
        send = findViewById(R.id.send);
        btn_whatsApp = findViewById(R.id.btn_whatsApp);
        textView = findViewById(R.id.textView);
        noTextView = findViewById(R.id.noTextView);
        vehicleNo = findViewById(R.id.vehicleNo);
        info = findViewById(R.id.info);
        numberText = findViewById(R.id.numberText);
        editText = findViewById(R.id.editTextNumber);
        sendToNo = findViewById(R.id.sendToNo);
        numText = findViewById(R.id.numText);
        viewImp = findViewById(R.id.viewImp);

        contact = new Contact(this);

        btn_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {choose();}
        });

        viewImp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewNum();
                sendToImp();
            }
        });

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    public void bus(View view) {
        noTextView.setText("Bus");
    }

    public void truck(View view) {
        noTextView.setText("Truck");
    }

    public void car(View view) {
        noTextView.setText("Car");
    }

    public void train(View view) {
        noTextView.setText("Train");
    }

    public void bike(View view) {
        noTextView.setText("Bike");
    }

    public void activa(View view) {
        noTextView.setText("Activa");
    }

    public void metro(View view) {
        noTextView.setText("Metro");
    }

    public void auto(View view) {
        noTextView.setText("Auto");
    }

    public void taxi(View view) {
        noTextView.setText("Taxi");
    }

    public void choose() {
        new MultiContactPicker.Builder(MainActivityThird.this) //Activity/fragment context
               .hideScrollbar(false) //Optional - default: false
               .showTrack(true) //Optional - default: true
               .searchIconColor(Color.WHITE) //Option - default: White
               .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
               .handleColor(ContextCompat.getColor(MainActivityThird.this, R.color.colorPrimary)) //Optional - default: Azure Blue
               .bubbleColor(ContextCompat.getColor(MainActivityThird.this, R.color.colorPrimary)) //Optional - default: Azure Blue
               .bubbleTextColor(Color.WHITE) //Optional - default: White
               .setTitleText("Select Contacts") //Optional - default: Select Contacts
               .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
               .limitToColumn(LimitColumn.NONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
               .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                       android.R.anim.fade_in,
                       android.R.anim.fade_out
               ) //Optional - default: No animation overrides
               .showPickerForResult(CONTACT_PICKER_REQUEST);

    }

    public void sendContact (View view) {
        String Message = textView.getText().toString() +" "+ noTextView.getText().toString() +"\n"+ vehicleNo.getText().toString() +"\n"+ info.getText().toString();

        if (!results.isEmpty()) {

            if(!Message.isEmpty()) {

                for(int j=0; j<results.size(); j++) {

                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(results.get(j).getPhoneNumbers().get(0).getNumber(), null, Message, null, null);

                    Toast.makeText(this, "Message Send", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please Click On Get Location!", Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void openWhatsApp(View view) {
        PackageManager pm = getPackageManager();
        try {
            Intent waIntent = new Intent(Intent.ACTION_SEND);
            waIntent.setType("text/plain");
            String text = textView.getText().toString() +" "+ noTextView.getText().toString() +"\n"+ vehicleNo.getText().toString() +"\n"+ info.getText().toString();

            PackageInfo info = pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA);
            //Check if package exists or not. If not then code
            //in catch block will be called
            waIntent.setPackage("com.whatsapp");

            waIntent.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(waIntent, "Share with"));

        } catch (PackageManager.NameNotFoundException e) {
            Toast.makeText(this, "WhatsApp not Installed", Toast.LENGTH_SHORT)
                 .show();
        } catch (Exception e) {
        }
    }

    public void sendTo(View view) {
        String Number = editText.getText().toString() ;
        String Message = textView.getText().toString() +" "+ noTextView.getText().toString() +"\n"+ vehicleNo.getText().toString() +"\n"+ info.getText().toString();
        if(!textView.getText().toString().isEmpty()) {

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(Number, null, Message, null, null);

            Toast.makeText(this, "Message Send", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please Click On Get Location!", Toast.LENGTH_SHORT).show();
        }
    }

    public  void ViewNum() {
        Cursor data = contact.showData();

        if (data.getCount() == 0) {
            display("ERROR", "NO DATA FOUND");
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (data.moveToNext()) {
            buffer.append(data.getString(2) + ",");
        }
        numText.setText(buffer.toString());
    }

    public void display(String title, String message) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void sendToImp() {

        String Message = textView.getText().toString() +" "+ noTextView.getText().toString() +"\n"+ vehicleNo.getText().toString() +"\n"+ info.getText().toString();
        String Number = numText.getText().toString();

        if(!textView.getText().toString().isEmpty()) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(Number, null, Message, null, null);
            Toast.makeText(this, "Message Send", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Please Click On Get Location!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CONTACT_PICKER_REQUEST){
            if(resultCode == RESULT_OK) {
                results = MultiContactPicker.obtainResult(data);
                StringBuilder names = new StringBuilder(results.get(0).getDisplayName());
                for (int j = 0; j < results.size(); j++) {
                    if (j != 0) {
                        names.append(", ").append(results.get(j).getDisplayName());
                    }
                }
                numberText.setText(names);
            }
        } else if(resultCode == RESULT_CANCELED){
            System.out.println("User closed the picker without selecting items.");
        }
    }
}