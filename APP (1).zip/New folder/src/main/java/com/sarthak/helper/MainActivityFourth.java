package com.sarthak.helper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivityFourth extends AppCompatActivity {

    EditText e1;
    Button btn;
    TextView textView;

    SharedPreferences sharedpreferences;

    public static final String MyPREFERENCES = "com.sarthak.locationsender";
    public static final String Name = "nameKey";
    String name;
    String get;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_fourth);

        e1 = findViewById(R.id.e1);
        textView = findViewById(R.id.textView);

        btn = findViewById(R.id.btn);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        get= e1.getText().toString();

        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(MainActivityFourth.this);
        name = settings.getString("name", get );
        textView.setText(name);
    }

    public void saveName(View view) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(Name, get);
        editor.commit();
    }
    }
