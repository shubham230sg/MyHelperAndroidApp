package com.sarthak.helper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.location.LocationManager.*;

public class MainActivity extends AppCompatActivity {

    private static final int CONTACT_PICKER_REQUEST = 3 ;
    Button button;
    TextView textView;
    TextView numberText;
    Button btn;
    Button btn_send;
    ImageButton second;
    EditText editText;
    Button btn_sendTo;
    TextView numText;
    Button viewImp;
    Contact contact;
    AdView mAdView;



    public LocationManager locationManager;
    public LocationListener locationListener = new MyLocationListener();
    List< ContactResult > results = new ArrayList <>();
    List < Address > address = new ArrayList <>();

    public void goToSecond(View view) {
        Intent intent = new Intent(getApplicationContext(),MainActivitySecond.class);
        startActivity(intent);
    }

    public void goToThird(View view) {
        Intent intent = new Intent(getApplicationContext(),MainActivityThird.class);
        startActivity(intent);
    }

    public void goToFourth(View view) {
        Intent intent = new Intent(getApplicationContext(),MainActivityFifth.class);
        startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        textView = findViewById(R.id.textView);
        numberText = findViewById(R.id.numberText);
        btn = findViewById(R.id.choose);
        btn_send = findViewById(R.id.send1);
        second = findViewById(R.id.second);
        editText = findViewById(R.id.editTextNumber);
        btn_sendTo = findViewById(R.id.sendToNo);
        numText = findViewById(R.id.numText);
        viewImp = findViewById(R.id.viewImp);

        contact = new Contact(this);

        Dexter.withContext(this)
              .withPermissions(
                      Manifest.permission.SEND_SMS,
                      Manifest.permission.READ_CONTACTS,
                      Manifest.permission.ACCESS_FINE_LOCATION,
                      Manifest.permission.CALL_PHONE

              ).withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport report) {/* ... */}

            @Override
            public void onPermissionRationaleShouldBeShown(List < PermissionRequest > list, PermissionToken permissionToken) {/* ... */}

        }).check();


        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseCont();
            }
        });
        viewImp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewNum();
                sendToImp();
            }
        });

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }



    class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {

            Double log = location.getLongitude();
            Double lat = location.getLatitude();

            try {
                Geocoder geoCoder = new Geocoder(getApplicationContext(), Locale.getDefault());

                address = geoCoder.getFromLocation(lat, log, 1);

                textView.setText(address.get(0).getAddressLine(0)  +" \nLat :  " + lat + " \nLog :  " + log);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {
            enableGPS();
        }
    }

    public void enableGPS() {

        AlertDialog.Builder alerDialogbuilder = new AlertDialog.Builder(MainActivity.this);
        alerDialogbuilder.setTitle("Enable GPS to Continue");
        alerDialogbuilder.setMessage("If You Want To Enable GPS Go To Settings");
        alerDialogbuilder.setCancelable(false);
        alerDialogbuilder.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent1 = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent1);
                Toast.makeText(getApplicationContext(),"Enable GPS..",Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog alertDialog = alerDialogbuilder.create();
        alertDialog.show();
    }

    public void getLocation() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION},1);


        } else {
            locationManager.requestLocationUpdates(GPS_PROVIDER,0,0,locationListener);
            int permissionCheck1 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) ;
        }
    }


    public void send(View view) {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ;
        if(permissionCheck == PackageManager.PERMISSION_GRANTED ) {
            MyMessage();
        } else  {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS},2);
        }
    }

    public void chooseCont() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) ;
        if(permissionCheck == PackageManager.PERMISSION_GRANTED ) {
            choose();
        } else  {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_CONTACTS},7);
        }
    }

    public void choose() {
        new MultiContactPicker.Builder(MainActivity.this) //Activity/fragment context
                                                          .hideScrollbar(false) //Optional - default: false
                                                          .showTrack(true) //Optional - default: true
                                                          .searchIconColor(Color.WHITE) //Option - default: White
                                                          .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                                                          .handleColor(ContextCompat.getColor(MainActivity.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                                          .bubbleColor(ContextCompat.getColor(MainActivity.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                                          .bubbleTextColor(Color.WHITE) //Optional - default: White
                                                          .setTitleText("Select Contacts") //Optional - default: Select Contacts
                                                          .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                                                          .limitToColumn(LimitColumn.NONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                                                          .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                                                                  android.R.anim.fade_in,
                                                                  android.R.anim.fade_out) //Optional - default: No animation overrides
                                                          .showPickerForResult(CONTACT_PICKER_REQUEST);

    }

    private void MyMessage() {
        String Number = "7807445066" ;
        if(!textView.getText().toString().isEmpty()) {

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(Number, null, textView.getText().toString(), null, null);

            Toast.makeText(this, "Message Send", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please Click On Get Location!", Toast.LENGTH_SHORT).show();
        }
    }

    public void sendTo(View view) {
        String Number = editText.getText().toString() ;
        if(!textView.getText().toString().isEmpty()) {
            if(!Number.isEmpty()) {

                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(Number, null, textView.getText().toString(), null, null);

                Toast.makeText(this, "Message Send", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please Enter Number", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please Click On Get Location!", Toast.LENGTH_SHORT).show();
        }
    }

    public void sendContact(View view) {

        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ;
        if(permissionCheck == PackageManager.PERMISSION_GRANTED ) {
            contMessage();
        } else  {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS},2);
        }
    }

    private void contMessage() {
        String Message = textView.getText().toString();

        if (!results.isEmpty()) {

            if(!Message.isEmpty()) {

                for(int j=0; j<results.size(); j++) {

                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(results.get(j).getPhoneNumbers().get(0).getNumber(), null, textView.getText().toString(), null, null);

                    Toast.makeText(this, "Message Send", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please Click On Get Location!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please Select Your Contact First!", Toast.LENGTH_SHORT).show();
        }
    }

    public void openWhatsApp(View view){
        PackageManager pm=getPackageManager();
        try {
            Intent waIntent = new Intent(Intent.ACTION_SEND);
            waIntent.setType("text/plain");
            String text = textView.getText().toString() ;

            PackageInfo info=pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA);
            //Check if package exists or not. If not then code
            //in catch block will be called
            waIntent.setPackage("com.whatsapp");

            waIntent.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(waIntent, "Share with"));

        } catch (PackageManager.NameNotFoundException e) {
            Toast.makeText(this, "WhatsApp not Installed", Toast.LENGTH_SHORT)
                 .show();
        }catch(Exception e){
        }
    }

    public  void ViewNum() {
        Cursor data = contact.showData();

        if (data.getCount() == 0) {
            display("ERROR", "NO DATA FOUND");
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (data.moveToNext()) {
            buffer.append(data.getString(2) + ",");
        }
        numText.setText(buffer.toString());
    }

    public void display(String title, String message) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void sendToImp() {

        String Number = numText.getText().toString();

        if(!textView.getText().toString().isEmpty()) {
            if(!Number.isEmpty()) {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(Number, null, textView.getText().toString(), null, null);
                Toast.makeText(this, "Message Send", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please Enter Your Emergency Contacts First", Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(this, "Please Click On Get Location!", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CONTACT_PICKER_REQUEST){
            if(resultCode == RESULT_OK) {
                results = MultiContactPicker.obtainResult(data);
                StringBuilder names = new StringBuilder(results.get(0).getDisplayName());
                for (int j = 0; j < results.size(); j++) {
                    if (j != 0) {
                        names.append(", ").append(results.get(j).getDisplayName());
                    }
                }
                numberText.setText(names);
            }
        } else if(resultCode == RESULT_CANCELED){
            System.out.println("User closed the picker without selecting items.");
        }
    }

}
